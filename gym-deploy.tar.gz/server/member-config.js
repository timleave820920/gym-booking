/**
 * 会员体系统一配置（唯一数据源）
 * ============================================================
 * 修改本文件的数值后，全端（后端 + 小程序）自动生效：
 *  - 后端 db.js 直接读取本文件
 *  - 前端通过 GET /api/member/config 动态获取
 * 无需修改任何其他文件。修改后重启后端即可。
 * ============================================================
 */

module.exports = {
  // 会员等级：青铜(0节/98折) 白银(20节/95折) 黄金(50节/92折) 钻石(100节/88折)
  // lv: 等级序号（从 1 开始）｜ min: 升级所需累计课时 ｜ discount: 会员折扣（0.98 = 98折）
  levels: [
    { name: '青铜', lv: 1, min: 0,   discount: 0.98 },
    { name: '白银', lv: 2, min: 20,  discount: 0.95 },
    { name: '黄金', lv: 3, min: 50,  discount: 0.92 },
    { name: '钻石', lv: 4, min: 100, discount: 0.88 }
  ],

  // 储值套餐：amount 充值金额（分）｜ firstBonusRate 每档首次充值赠送比例（0.3 = 送30%）
  //                          ｜ repeatBonusRate 复充赠送比例（0.1 = 送10%）
  // 例：50000 = ¥500，首充送 ¥150，之后每次送 ¥50
  rechargePlans: [
    { id: 1, amount: 50000,  firstBonusRate: 0.30, repeatBonusRate: 0.10 },
    { id: 2, amount: 150000, firstBonusRate: 0.30, repeatBonusRate: 0.10 },
    { id: 3, amount: 300000, firstBonusRate: 0.30, repeatBonusRate: 0.10 }
  ],

  // 邀请奖励阶梯（储值发放，单位：分）：好友完成首订后按累计人数发放
  // 注意：阶梯奖励为"到达即发放增量"（1人发100，到3人补发400，到5人补发500）
  inviteRewards: [
    { at: 1, fen: 10000 },   // 邀请 1 人 → ¥100（相当于 1 节课）
    { at: 3, fen: 50000 },   // 邀请 3 人 → 累计 ¥500（5 节课）
    { at: 5, fen: 100000 }   // 邀请 5 人 → 累计 ¥1000（10 节课）
  ],

  // 会员价规则：仅储值余额支付享受等级折扣
  memberPrice: {
    enabled: true,           // 是否启用会员价
    scope: 'balance'         // balance = 仅储值支付享折扣 / all = 所有支付方式
  },

  // 前端展示用元信息（等级图标/颜色等，可随配置调整）
  // icon：奖牌表达——青铜🥉 白银🥈 黄金🥇 钻石💎
  levelStyles: [
    { name: '青铜', roman: 'Ⅰ', icon: '🥉', color: '#D89C4C' },
    { name: '白银', roman: 'Ⅱ', icon: '🥈', color: '#B8C4CE' },
    { name: '黄金', roman: 'Ⅲ', icon: '🥇', color: '#F2C43B' },
    { name: '钻石', roman: 'Ⅳ', icon: '💎', color: '#8C84F2' }
  ]
};
